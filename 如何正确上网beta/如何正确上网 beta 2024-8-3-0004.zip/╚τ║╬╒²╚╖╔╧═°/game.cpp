#include <bits/stdc++.h>
#include <windows.h>
#define reset_color SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
#define otpt(q) printf(q);
#define otptln(q) printf(q);printf("\n");
#define lnotpt(q) printf("\n");printf(q);
#define lnotptln(q) printf("\n");printf(q);printf("\n");
#define otptin SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),14);printf(">");SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
#define cls system("cls");
#define err_cannot_play printf("\n你还没有解锁此关卡。\n");
using namespace std;
int Main[1+1][4+1], Side[4+1][0+1], Know[12+1];
int now_save=1;
bool auto_save=0, know_image=0;
struct STRsingle
{
	string tex="";
};
struct STRdouble
{
	string tit="";
	string tex="";
};
STRsingle Mainstr[1+1];
STRsingle Sidestr[4+1];
STRsingle MainMissionstr[4+1];
//STRsingle SideMissionstr[0+1];
STRdouble Knowstr[12+1];

//void side00();
void side10();
//void side20();
//void side30();
//void side40();
void main11();
//void main12();
//void main13();
//void main14();
void change_color(int a)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),a);
	return;
}
void chose_mission_cc(int a)
{
	if(a==0)
	{
		return;
	}
	if(a==1)
	{
		change_color(14);
	}
	if(a==2)
	{
		change_color(10);
	}
}

void read_save()//读档
{
	char _x;
	int _a,_b,_c;
	//scanf("%[^\n]");scanf("%[^\n]");
	do
	{
		cin>>_x;
		if(_x=='m' or _x=='s')
		{
			cin>>_a>>_b>>_c;
			if(_x=='m')
				Main[_a][_b]=_c;
			if(_x=='s')
				Side[_a][_b]=_c;
		}
		else if(_x=='k')
		{
			cin>>_a;
			Know[_a]=1;
		}
	}while(_x!='e');
	return;
}
void write_save()//写档
{
	int i,j;
	for(i=0;i<1+1;i++)
	{
		for(j=0;j<4+1;j++)
		{
			cout<<"m "<<i<<' '<<j<<' '<<Main[i][j]<<endl;
		}
	}
	for(i=0;i<4+1;i++)
	{
		for(j=0;j<0+1;j++)
		{
			cout<<"s "<<i<<' '<<j<<' '<<Side[i][j]<<endl;
		}
	}
	for(i=0;i<12+1;i++)
	{
		cout<<"k "<<Know[i]<<' ';
	}
	cout<<'e';
	cout<<"\n\n//next ln will not be read.\n//Formart:\n//0=cannot play; 1=can play; 2=completed.\n//Main X Mission X 0/1/2;\n//Side X Mission X 0/1/2;\n//Knowledge X.\n//end as 'e'.";
	return;
}
void chose_rwsave()//档位操作
{
	char _x;
	STRsingle temp_a[2];
	temp_a[0].tex="Off";
	temp_a[1].tex="On";
	cout<<"\n当前档位："<<now_save;
	cout<<"\n自动存档（任务完成时自动存到当前存档）："<<temp_a[auto_save].tex<<endl;
	lnotptln("输入：\na开关自动存档 c仅切换档位\nr仅读档 R切换档位并读档\nw仅存档 W切换档位并存档\nq退出\n注：切换档位后不会自动读档；存档会自动存在当前档位")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='a' and _x!='c' and _x!='r' and _x!='R' and _x!='w' and _x!='W' and _x!='q');
	if(_x=='q')return;
	if(_x=='a')
	{
		auto_save=!auto_save;
		chose_rwsave();
	}
	if(_x=='c' or _x=='R' or _x=='W')
	{
		lnotptln("请选择档位 1/2/3/4/5 输入档位编号")
		do
		{
			otptin
			cin>>now_save;
		}while(now_save<1 or now_save>5);
	}
	if(_x=='r' or _x=='R')
	{
		if(now_save==1)freopen("01sav.msi","r",stdin);
		if(now_save==2)freopen("02sav.msi","r",stdin);
		if(now_save==3)freopen("03sav.msi","r",stdin);
		if(now_save==4)freopen("04sav.msi","r",stdin);
		if(now_save==5)freopen("05sav.msi","r",stdin);
		read_save();
		freopen("CON","r",stdin);
	}
	if(_x=='w' or _x=='W')
	{
		if(now_save==1)
		{
			system("del /f /q \".\\01sav.msi\"");
			freopen("01sav.msi","w",stdout);
		}
		if(now_save==2)
		{
			system("del /f /q \".\\02sav.msi\"");
			freopen("02sav.msi","w",stdout);
		}
		if(now_save==3)
		{
			system("del /f /q \".\\03sav.msi\"");
			freopen("03sav.msi","w",stdout);
		}
		if(now_save==4)
		{
			system("del /f /q \".\\04sav.msi\"");
			freopen("04sav.msi","w",stdout);
		}
		if(now_save==5)
		{
			system("del /f /q \".\\05sav.msi\"");
			freopen("05sav.msi","w",stdout);
		}
		write_save();
		freopen("CON","w",stdout);
	}
	return;
}
void opn(char file_location[],char file_name[])//open 打开一个文件
{
	int i,loca_len=strlen(file_location),name_len=strlen(file_name);
	char _x[100000]="copy /y /z ",_y[]=" \".\\file\\temp\\\"";
	char _xx[100000]="start \".\\file\\temp\\";
	for(i=11;i<11+loca_len;i++)
	{
		_x[i]=file_location[i-11];
	}
	for(;i<11+loca_len+15;i++)
	{
		_x[i]=_y[i-11-loca_len];
	}
	for(i=19;i<19+name_len;i++)
	{
		_xx[i]=file_name[i-19];
	}_xx[i]=34;
	system(_x);
	system(_xx);
	return;
}
void optin()//option 选项/设置
{
	char _x;
	STRdouble temp_a[2];
	temp_a[0].tit="Off";
	temp_a[1].tit="On";
	temp_a[0].tex="文字";
	temp_a[1].tex="图片";
	cout<<"\n自动存档（任务完成时自动存到当前存档）："<<temp_a[auto_save].tit<<endl;
	cout<<"知识展示形式："<<temp_a[know_image].tex<<endl;
	lnotptln("输入：s开关自动存档 k切换知识展示形式 q退出")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='s' and _x!='k' and _x!='q');
	if(_x=='s')
	{
		auto_save=!auto_save;
		optin();
	}
	if(_x=='k')
	{
		know_image=!know_image;
		optin();
	}
	if(_x=='q')
	{
		return;
	}
}
void otpt_know()//查看知识
{
	int i,x;
	bool _temp=1;
	for(i=0;i<12+1;i++)if(Know[i]==1)_temp=0;
	if(_temp)
	{
		lnotptln("当前无可查看知识！按回车继续。")
		getchar();getchar();
		return;
	}
	lnotptln("当前可查看的知识：")
	for(i=0;i<12+1;i++)
	{
		if(Know[i]==1)
		{
			cout<<"知识"<<i<<' '<<Knowstr[i].tit<<endl;
		}
	}
	lnotptln("输入你想查看的知识：")
	do
	{
		otptin
		cin>>x;
	}while(x<0 or x>12+1);
	otptln("")
	cout<<"知识"<<x<<' '<<Knowstr[x].tit<<endl;
	cout<<Knowstr[x].tex<<endl;
	lnotptln("按回车继续。")
	getchar();getchar();
	return;
}
void otpt_new_know(int x)//查看新知识
{
	cout<<"\n恭喜解锁新知识！知识"<<x<<' '<<Knowstr[x].tit<<endl;
	cout<<Knowstr[x].tex<<endl;
	lnotptln("按回车继续。")
	getchar();getchar();
	return;
}

void wait_next()
{
	char _x;
	do
	{
		otptin
		cin>>_x;
	}while(_x!='n' and _x!='k');
	if(_x=='k')
	{
		otpt_know();
	}
	if(_x=='n')
	{
		return;
	}
}
void wait_next_with_cmd(char q[])
{
	char _x;
	do
	{
		otptin cin>>_x;
	}while(_x!='n' and _x!='k' and _x!='o');
	if(_x=='k')
	{
		otpt_know();
	}
	if(_x=='o')
	{
		system(q);
	}
	if(_x=='n')
	{
		return;
	}
}
void wait_next_with_open(char q[],char r[])
{
	char _x;
	do
	{
		otptin cin>>_x;
	}while(_x!='n' and _x!='k' and _x!='o');
	if(_x=='k')
	{
		otpt_know();
	}
	if(_x=='o')
	{
		opn(q,r);
	}
	if(_x=='n')
	{
		return;
	}
}

void chose_mission()//关卡/任务选择
{
	int x;
	string temp_a[3];
	temp_a[0]="未解锁";
	temp_a[1]="已解锁";
	temp_a[2]="已完成";
	cout<<"\n当前档位："<<now_save;
	lnotptln("输入-1换挡读档存档")
	otptln("输入-2返回菜单")
	lnotptln("请选择你的任务：")
	chose_mission_cc(Side[0][0]); cout<<"编号0 支线0：		"<<Sidestr[0].tex<<"				"<<temp_a[Side[0][0]]<<endl;	 reset_color
	chose_mission_cc(Side[1][0]); cout<<"编号1 支线1：		"<<Sidestr[1].tex<<"				"<<temp_a[Side[1][0]]<<endl;	 reset_color
	chose_mission_cc(Side[2][0]); cout<<"编号2 支线2：		"<<Sidestr[2].tex<<"				"<<temp_a[Side[2][0]]<<endl;	 reset_color
	chose_mission_cc(Side[3][0]); cout<<"编号3 支线3：		"<<Sidestr[3].tex<<"				"<<temp_a[Side[3][0]]<<endl;	 reset_color
	chose_mission_cc(Main[1][1]); cout<<"编号4 主线1任务1：	"<<MainMissionstr[1].tex<<"				"<<temp_a[Main[1][1]]<<endl; reset_color
	chose_mission_cc(Side[4][0]); cout<<"编号5 支线4：		"<<Sidestr[4].tex<<"				"<<temp_a[Side[4][0]]<<endl;	 reset_color
	chose_mission_cc(Main[1][2]); cout<<"编号6 主线1任务2：	"<<MainMissionstr[2].tex<<"	"<<temp_a[Main[1][2]]<<endl;			 reset_color
	chose_mission_cc(Main[1][3]); cout<<"编号7 主线1任务3：	"<<MainMissionstr[3].tex<<"		"<<temp_a[Main[1][3]]<<endl;		 reset_color
	chose_mission_cc(Main[1][4]); cout<<"编号8 主线1任务4：	"<<MainMissionstr[4].tex<<"				"<<temp_a[Main[1][4]]<<endl; reset_color
	do
	{
		otptin
		cin>>x;
	}while(x<-2 or x>12+1);
	if(x==-2)
	{
		return;
	}
	if(x==-1)
	{
		chose_rwsave();
		chose_mission();
	}
	if(x==0)
	{
//		side00();
		chose_mission();
	}
	if(x==1)
	{
		side10();
		chose_mission();
	}
	if(x==2)
	{
//		side20();
		chose_mission();
	}
	if(x==3)
	{
//		side30();
		chose_mission();
	}
	if(x==4)
	{
		main11();
		chose_mission();
	}
	if(x==5)
	{
//		side40();
		chose_mission();
	}
	if(x==6)
	{
//		main12();
		chose_mission();
	}
	if(x==7)
	{
//		main13();
		chose_mission();
	}
	if(x==8)
	{
//		main14();
		chose_mission();
	}
	return;
}
void chose()//开始菜单
{
	char _x;chose_a:
	lnotptln("输入：s开始line(线)任务 k查看知识 o打开设置 c换挡读档写档")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='s' and _x!='k' and _x!='o' and _x!='c');
	if(_x=='s')
	{
		chose_mission();
		chose();
	}
	if(_x=='k')
	{
		otpt_know();
		chose();
	}
	if(_x=='o')
	{
		optin();
		chose();
	}
	if(_x=='c')
	{
		chose_rwsave();
		chose();
	}
	return;
}
int main()
{
	system("title 如何正确上网 beta v1.0.0 2024-8-3-0004");
	Mainstr[1].tex="使用浏览器";
	
	Sidestr[0].tex="快捷键使用教程";
	Sidestr[1].tex="下载浏览器";
	Sidestr[2].tex="安装浏览器";
	Sidestr[3].tex="卸载浏览器";
	Sidestr[4].tex="网站无法访问";
	
	MainMissionstr[1].tex="打开一个网址";
	MainMissionstr[2].tex="尝试下载一个正版软件，或找到官方网站";
	MainMissionstr[3].tex="找到7-Zip的官网并复制网址";
	MainMissionstr[4].tex="浏览器的设置";
	
	Knowstr[1].tit="快捷键";
	Knowstr[2].tit="浏览器";
	Knowstr[3].tit="桌面";
	Knowstr[4].tit="快捷方式";
	Knowstr[5].tit="开始菜单";
	Knowstr[6].tit="文件类型";
	Knowstr[7].tit="下载";
	Knowstr[8].tit="安装包";
	Knowstr[9].tit="垃圾软件";
	Knowstr[10].tit="网址、域名、IP";
	Knowstr[11].tit="网址栏、搜索框";
	Knowstr[12].tit="搜索引擎、关键字";
	
	Knowstr[1].tex="暂未更新";
	Knowstr[2].tex="暂未更新";
	Knowstr[3].tex="暂未更新";
	Knowstr[4].tex="暂未更新";
	Knowstr[5].tex="暂未更新";
	Knowstr[6].tex="暂未更新";
	Knowstr[7].tex="暂未更新";
	Knowstr[8].tex="暂未更新";
	Knowstr[9].tex="暂未更新";
	Knowstr[10].tex="暂未更新";
	Knowstr[11].tex="暂未更新";
	Knowstr[12].tex="暂未更新";
	char _x;
	otptln("嗨，朋友，感谢游玩《如何正确上网》。")
	otptln("本游戏输入完后需要按回车；如果输入错误可以重新输入。")
	otptln("如果嫌字小，在这个窗口按住Ctrl键，同时上下滚动鼠标滚轮即可调整字体。")
	otptln("输入s开始游戏，输入i查看版本信息。")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='s' and _x!='i');
	if(_x=='i')
	{
		otptln("version 1.0.0 2024-8-3-0004")
		otptln("by Alone, IQ Online Studio 智商在线工作室 QQ:34067513 官网: https://hitele.github.io/how_to_surf_internet/a.html")
		lnotptln("按回车开始游戏")
		otptin
		getchar();getchar();
		_x='s';
	}
	if(_x=='s')
	{
		lnotptln("读取存档：请选择档位 1/2/3/4/5 输入档位编号")
		do
		{
			otptin
			cin>>now_save;
		}while(now_save<1 or now_save>5);
		if(now_save==1)freopen("01sav.msi","r",stdin);
		if(now_save==2)freopen("02sav.msi","r",stdin);
		if(now_save==3)freopen("03sav.msi","r",stdin);
		if(now_save==4)freopen("04sav.msi","r",stdin);
		if(now_save==5)freopen("05sav.msi","r",stdin);
		read_save();
		freopen("CON","r",stdin);
//		otptln("")
		chose();
	}
	return 0;
}
//void side00();
void side10()
{
	if(Side[0][0]==0)
	{
		err_cannot_play
		return;
	}
	cls
	cout<<"\n支线1 "<<Sidestr[1].tex<<endl;
	lnotptln("如果你要学会上网，那么你就需要一款趁手的浏览器。当然，系统自带的Internet Explorer浏览器，或是Microsoft Edge浏览器是完全不够用的。因此，我们我需要下载一款浏览器；而为了下载这款浏览器，只能将就使用系统自带的浏览器来下载。输入n继续，输入k查看知识。")
	wait_next();
	Know[2]=1;
	otpt_new_know(2);
	cls
	lnotptln("现在，游戏将教你如何打开一个应用程序。")
	otptln("常见的打开方式有几种：桌面快捷方式打开、开始菜单打开和直接打开程序的文件。")
	lnotptln("桌面快捷方式打开")
	lnotptln("你只需要在桌面上找到你想打开的程序的快捷方式图标，把光标移动到上面，快速点两下即可。")
	Know[3]=1;
	otpt_new_know(3);
	Know[4]=1;
	otpt_new_know(4);
	lnotptln("输入o打开教程视频，输入n继续，输入k查看知识。")
	wait_next_with_cmd("echo hello");
	
	cls
	lnotptln("开始菜单打开")
	lnotptln("点击任务栏上“田”字形的Windows徽标，或按下键盘上的Windows键，即可打开开始菜单。在开始菜单内找到你想打开的程序，点击即可打开；有些程序可能在文件夹内，需要先打开文件夹再点击程序。")
	Know[5]=1;
	otpt_new_know(5);
	lnotptln("输入o打开教程视频，输入n继续，输入k查看知识。")
	wait_next_with_cmd("echo hello");
	
	cls
	lnotptln(".exe可执行文件打开")
	lnotptln("大部分应用程序本质上就是一个.exe格式的文件（又称可执行文件）。我们可以像打开文件一样直接双击打开这个程序。")
	Know[6]=1;
	otpt_new_know(6);
	lnotptln("输入o打开教程视频，输入n继续，输入k查看知识。//更新中……")
	wait_next_with_cmd("echo hello");
}
//支线1：下载浏览器（询问是否有浏览器）
//    知识2：浏览器
//    软件的打开
//        桌面快捷方式（打开图片）
//            知识3：桌面
//            知识4：快捷方式
//        开始菜单（打开图片）
//            知识5：开始菜单
//        .exe可执行文件
//            知识6：文件类型
//            显示文件扩展名（分步教学）
//    打开私货网页要求玩家下载一个浏览器
//        知识7：下载
//    找到下载的文件
//        打开下载记录
//            找按钮
//            Ctrl+J
//        打开文件位置
//void side20();
//void side30();
//void side40();
void main11()
{
	if(Main[1][1]==0)
	{
		err_cannot_play
		return;
	}
	int x;
	cls
	cout<<"\n主线1任务1 "<<MainMissionstr[1].tex<<endl;
	lnotptln("你已经学会了如何打开浏览器。我们为你惊心制作了一款浏览器，马上为你打开！注：自制浏览器m11版本没有上网功能，仅供游戏流程。输入n继续，输入k查看知识。")
	wait_next();
	Know[10]=1;
	otpt_new_know(10);
	cls
	lnotptln("请尝试将下面这段网址复制到自制浏览器的网址栏，并打开这个网址。")
	lnotptln("通关码：715829")
	lnotptln("如果你正确操作的话，你将会看到一串通关码。将它输入到下面并按回车即可完成任务（太简单了）！警告：通关码为纯数字，如果你输入数字位数超过上限，或输入别的字符，程序将会卡退，耗子尾汁。");
	otptin
	cin>>x;
	while(x!=715829)
	{
		lnotptln("哦，通关码错误。请检查输入是否有误，然后重新输入。如果无法完成任务请输入123456来退出任务。")
		otptin
		cin>>x;
		if(x==123456)return;
	}
	Main[1][1]=2;
	Side[4][0]=1;
	Main[1][2]=1;
	cls
	cout<<"\n祝贺！你已完成主线1任务1 "<<MainMissionstr[1].tex<<"。"<<endl;
	cout<<"\n已解锁：支线4 "<<Sidestr[4].tex<<endl;
	cout<<"\n已解锁：主线1任务2 "<<MainMissionstr[2].tex<<endl;
	if(auto_save)
	{
		if(now_save==1)
		{
			system("del /f /q \".\\01sav.msi\"");
			freopen("01sav.msi","w",stdout);
		}
		if(now_save==2)
		{
			system("del /f /q \".\\02sav.msi\"");
			freopen("02sav.msi","w",stdout);
		}
		if(now_save==3)
		{
			system("del /f /q \".\\03sav.msi\"");
			freopen("03sav.msi","w",stdout);
		}
		if(now_save==4)
		{
			system("del /f /q \".\\04sav.msi\"");
			freopen("04sav.msi","w",stdout);
		}
		if(now_save==5)
		{
			system("del /f /q \".\\05sav.msi\"");
			freopen("05sav.msi","w",stdout);
		}
		write_save();
		freopen("CON","w",stdout);
		lnotpt("已为你自动保存存档至存档")
		cout<<now_save<<endl;
	}
	return;
}
//void main12();
//void main13();
//void main14();
