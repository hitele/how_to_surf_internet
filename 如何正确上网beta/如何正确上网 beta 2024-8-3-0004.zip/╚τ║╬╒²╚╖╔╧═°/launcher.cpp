#include <bits/stdc++.h>
#include <windows.h>
#define otpt(q) printf(q);
#define otptln(q) printf(q);printf("\n");
#define lnotpt(q) printf("\n");printf(q);
#define lnotptln(q) printf("\n");printf(q);printf("\n");
#define otptin SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),14);printf(">");SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
using namespace std;
int main()
{
	char x;
	otptln("嗨，朋友，感谢游玩《如何正确上网》。")
	otptln("输入完后需要按回车。")
	otptln("这是一个启动器，用于游戏的启动与管理。")main_a:
	otptln("输入：s启动游戏 d清空缓存 r重置存档 w打开官网 u卸载游戏。")
	do
	{
		otptin
		cin>>x;
	}while(x!='s' and x!='d' and x!='r' and x!='w' and x!='u');
	if(x=='s')
	{
		system("start game.exe");
	}
	if(x=='d')
	{
		system("del /f /q \".\\file\\temp\\*.*\"");
		lnotptln("缓存已经清空。\n")
	}
	if(x=='r')
	{
		lnotptln("选择一个档位重置：1/2/3/4/5 输入档位编号")
		int x;
		do
		{
			otptin
			cin>>x;
		}while(x<1 or x>5);
		if(x==1)
		{
			system("del /f /q \".\\01sav.msi\"");
			system("copy /y /z \".\\file\\sav\\01sav.msi\" \".\\\"");
		}
		if(x==2)
		{
			system("del /f /q \".\\02sav.msi\"");
			system("copy /y /z \".\\file\\sav\\02sav.msi\" \".\\\"");
		}
		if(x==3)
		{
			system("del /f /q \".\\03sav.msi\"");
			system("copy /y /z \".\\file\\sav\\03sav.msi\" \".\\\"");
		}
		if(x==4)
		{
			system("del /f /q \".\\04sav.msi\"");
			system("copy /y /z \".\\file\\sav\\04sav.msi\" \".\\\"");
		}
		if(x==5)
		{
			system("del /f /q \".\\05sav.msi\"");
			system("copy /y /z \".\\file\\sav\\05sav.msi\" \".\\\"");
		}
		otptln("")
	}
	if(x=='w')
	{
		system("start https://hitele.github.io/how_to_surf_internet/a.html");
	}
	if(x=='u')
	{
		system("copy /y /z \".\\uninstall.bat\" \"C:\\Users\\%username%\\Desktop\\\"");
		otptln("卸载程序已经添加到你的桌面上，关闭这个窗口并打开桌面上的卸载程序即可完成卸载。")
	}
	goto main_a;
	return 0;
}
