#include <bits/stdc++.h>
#include <windows.h>
#define otpt(a) printf(a);
#define otptln(a) printf(a);printf("\n");
#define lnotpt(a) printf("\n");printf(a);
#define lnotptln(a) printf("\n");printf(a);printf("\n");
#define otptin SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),14);printf(">");SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
using namespace std;
bool Main[1+1][4+1], Side[4+1][0+1], Know[12+1];
struct STR
{
	string nam="";
	string tex="";
};
STR Knowstr[12+1];
void read_save()
{
	char x;
	int _a,_b,_c;
	//scanf("%[^\n]");scanf("%[^\n]");
	do
	{
		cin>>x;
		if(x=='m' or x=='s')
		{
			cin>>_a>>_b>>_c;
			if(x=='m')
				Main[_a][_b]=_c;
			if(x=='s')
				Side[_a][_b]=_c;
		}
		else if(x=='k')
		{
			cin>>_a;
			Know[_a]=true;
		}
	}while(x!='e');
	return;
}
void otpt_know()
{
	int i,x;
	bool _temp=true;
	for(i=0;i<12+1;i++)if(Know[i]==true)_temp=false;
	if(_temp)
	{
		lnotptln("当前无可查看知识！按回车继续。")
		getchar();
		return;
	}
	lnotptln("当前可查看的知识：")
	for(i=0;i<12+1;i++)
	{
		if(Know[i]==true)
		{
			cout<<"知识"<<i<<' '<<Knowstr[i].nam<<endl;
		}
	}
	lnotptln("输入你想查看的知识：")
	do
	{
		otptin
		cin>>x;
	}while(x<0 or x>12+1);
	otptln("")
	cout<<"知识"<<i<<' '<<Knowstr[x].nam<<endl;
	cout<<Knowstr[x].tex<<endl;
	lnotptln("按回车继续。")
	getchar();
	return;
}
void chose()
{
	char x;chose_a:
	lnotptln("输入s开始line(线)任务，输入k查看知识")
	do
	{
		otptin
		cin>>x;
	}while(x!='s' and x!='k');
	if(x=='s')
	{
		
	}
	if(x=='k')
	{
		otpt_know();
		goto chose_a;
	}
}
int main()
{
	Knowstr[1].nam="快捷键";
	Knowstr[2].nam="浏览器";
	Knowstr[3].nam="桌面";
	Knowstr[4].nam="快捷方式";
	Knowstr[5].nam="开始菜单";
	Knowstr[6].nam="文件类型";
	Knowstr[7].nam="下载";
	Knowstr[8].nam="安装包";
	Knowstr[9].nam="垃圾软件";
	Knowstr[10].nam="网址、域名、IP";
	Knowstr[11].nam="网址栏、搜索框";
	Knowstr[12].nam="搜索引擎、关键字";
	
	Knowstr[1].tex="暂未更新";
	Knowstr[2].tex="暂未更新";
	Knowstr[3].tex="暂未更新";
	Knowstr[4].tex="暂未更新";
	Knowstr[5].tex="暂未更新";
	Knowstr[6].tex="暂未更新";
	Knowstr[7].tex="暂未更新";
	Knowstr[8].tex="暂未更新";
	Knowstr[9].tex="暂未更新";
	Knowstr[10].tex="暂未更新";
	Knowstr[11].tex="暂未更新";
	Knowstr[12].tex="暂未更新";
	char x;
	otptln("嗨，朋友，感谢游玩《如何正确上网》。")
	otptln("本游戏输入完后需要按回车；如果输入错误可以重新输入。")
	otptln("如果嫌字小，在这个窗口按住Ctrl键，同时上下滚动鼠标滚轮即可调整字体。")
	otptln("输入s开始游戏，输入i查看版本信息。")
	do
	{
		otptin
		cin>>x;
	}while(x!='s' and x!='i');
	if(x=='i')
	{
		otptln("version 1.0.0 2024-8-2")
		otptln("by Alone, IQ Online Studio 智商在线工作室 QQ:34067513 官网: https://hitele.github.io/how_to_surf_internet/a.html")
		otptln("按回车开始游戏")
		otptin
		getchar();
		x='s';
	}
	if(x=='s')
	{
		otptln("读取存档：请选择存档 1/2/3")//多存档功能咕咕咕中
		freopen("01sav.msi","r",stdin);
		read_save();
		freopen("CON","r",stdin);
		otptln("")otptln("")
		chose();
	}
	return 0;
}
