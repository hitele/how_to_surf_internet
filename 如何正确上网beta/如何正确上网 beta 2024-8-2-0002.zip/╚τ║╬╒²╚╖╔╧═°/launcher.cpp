#include <bits/stdc++.h>
#include <windows.h>
#define otpt(q) printf(q);
#define otptln(q) printf(q);printf("\n");
#define lnotpt(q) printf("\n");printf(q);
#define lnotptln(q) printf("\n");printf(q);printf("\n");
#define otptin SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),14);printf(">");SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
using namespace std;
int Main[1+1][4+1], Side[4+1][0+1], Know[12+1];
bool auto_save=0;
struct STRsingle
{
	string tex="";
};
struct STRdouble
{
	string tit="";
	string tex="";
};
STRsingle Mainstr[1+1];
STRsingle Sidestr[4+1];
STRsingle MainMissionstr[4+1];
//STRsingle SideMissionstr[0+1];
STRdouble Knowstr[12+1];
void read_save()
{
	char x;
	int _a,_b,_c;
	//scanf("%[^\n]");scanf("%[^\n]");
	do
	{
		cin>>x;
		if(x=='m' or x=='s')
		{
			cin>>_a>>_b>>_c;
			if(x=='m')
				Main[_a][_b]=_c;
			if(x=='s')
				Side[_a][_b]=_c;
		}
		else if(x=='k')
		{
			cin>>_a;
			Know[_a]=1;
		}
	}while(x!='e');
	return;
}
void otpt_know()
{
	int i,x;
	bool _temp=1;
	for(i=0;i<12+1;i++)if(Know[i]==1)_temp=0;
	if(_temp)
	{
		lnotptln("当前无可查看知识！按回车继续。")
		getchar();
		return;
	}
	lnotptln("当前可查看的知识：")
	for(i=0;i<12+1;i++)
	{
		if(Know[i]==1)
		{
			cout<<"知识"<<i<<' '<<Knowstr[i].tit<<endl;
		}
	}
	lnotptln("输入你想查看的知识：")
	do
	{
		otptin
		cin>>x;
	}while(x<0 or x>12+1);
	otptln("")
	cout<<"知识"<<i<<' '<<Knowstr[x].tit<<endl;
	cout<<Knowstr[x].tex<<endl;
	lnotptln("按回车继续。")
	getchar();
	return;
}
void chose_mission()
{
	string temp_a[3];
	temp_a[0]="未解锁";
	temp_a[1]="已解锁";
	temp_a[2]="已完成";
	lnotptln("请选择你的任务：")
	cout<<"支线0：		"<<Sidestr[0].tex<<"				"<<temp_a[Side[0][0]]<<endl;
	cout<<"支线1：		"<<Sidestr[1].tex<<"				"<<temp_a[Side[1][0]]<<endl;
	cout<<"支线2：		"<<Sidestr[2].tex<<"				"<<temp_a[Side[2][0]]<<endl;
	cout<<"支线3：		"<<Sidestr[3].tex<<"				"<<temp_a[Side[3][0]]<<endl;
	cout<<"主线1任务1：	"<<MainMissionstr[1].tex<<"				"<<temp_a[Main[1][1]]<<endl;
	cout<<"支线4：		"<<Sidestr[4].tex<<"				"<<temp_a[Side[4][0]]<<endl;
	cout<<"主线1任务2：	"<<MainMissionstr[2].tex<<"	"<<temp_a[Main[1][2]]<<endl;
	cout<<"主线1任务3：	"<<MainMissionstr[3].tex<<"		"<<temp_a[Main[1][3]]<<endl;
	cout<<"主线1任务4：	"<<MainMissionstr[4].tex<<"				"<<temp_a[Main[1][4]]<<endl;
	return;
}
void chose()
{
	char x;chose_a:
	lnotptln("输入s开始line(线)任务，输入k查看知识")
	do
	{
		otptin
		cin>>x;
	}while(x!='s' and x!='k');
	if(x=='s')
	{
		chose_mission();
	}
	if(x=='k')
	{
		otpt_know();
		goto chose_a;
	}
}
int main()
{
	system("title 如何正确上网 beta v1.0.0 2024-8-2-0002");
	Mainstr[1].tex="使用浏览器";
	
	Sidestr[0].tex="快捷键使用教程";
	Sidestr[1].tex="下载浏览器";
	Sidestr[2].tex="安装浏览器";
	Sidestr[3].tex="卸载浏览器";
	Sidestr[4].tex="网站无法访问";
	
	MainMissionstr[1].tex="打开一个网址";
	MainMissionstr[2].tex="尝试下载一个正版软件，或找到官方网站";
	MainMissionstr[3].tex="找到7-Zip的官网并复制网址";
	MainMissionstr[4].tex="浏览器的设置";
	
	Knowstr[1].tit="快捷键";
	Knowstr[2].tit="浏览器";
	Knowstr[3].tit="桌面";
	Knowstr[4].tit="快捷方式";
	Knowstr[5].tit="开始菜单";
	Knowstr[6].tit="文件类型";
	Knowstr[7].tit="下载";
	Knowstr[8].tit="安装包";
	Knowstr[9].tit="垃圾软件";
	Knowstr[10].tit="网址、域名、IP";
	Knowstr[11].tit="网址栏、搜索框";
	Knowstr[12].tit="搜索引擎、关键字";
	
	Knowstr[1].tex="暂未更新";
	Knowstr[2].tex="暂未更新";
	Knowstr[3].tex="暂未更新";
	Knowstr[4].tex="暂未更新";
	Knowstr[5].tex="暂未更新";
	Knowstr[6].tex="暂未更新";
	Knowstr[7].tex="暂未更新";
	Knowstr[8].tex="暂未更新";
	Knowstr[9].tex="暂未更新";
	Knowstr[10].tex="暂未更新";
	Knowstr[11].tex="暂未更新";
	Knowstr[12].tex="暂未更新";
	char x;
	otptln("嗨，朋友，感谢游玩《如何正确上网》。")
	otptln("本游戏输入完后需要按回车；如果输入错误可以重新输入。")
	otptln("如果嫌字小，在这个窗口按住Ctrl键，同时上下滚动鼠标滚轮即可调整字体。")
	otptln("输入s开始游戏，输入i查看版本信息。")
	do
	{
		otptin
		cin>>x;
	}while(x!='s' and x!='i');
	if(x=='i')
	{
		otptln("version 1.0.0 2024-8-2")
		otptln("by Alone, IQ Online Studio 智商在线工作室 QQ:34067513 官网: https://hitele.github.io/how_to_surf_internet/a.html")
		otptln("按回车开始游戏")
		otptin
		getchar();getchar();
		x='s';
	}
	if(x=='s')
	{
		otptln("读取存档：请选择存档 1/2/3")//多存档功能咕咕咕中
		freopen("01sav.msi","r",stdin);
		read_save();
		freopen("CON","r",stdin);
		otptln("")otptln("")
		chose();
	}
	return 0;
}
