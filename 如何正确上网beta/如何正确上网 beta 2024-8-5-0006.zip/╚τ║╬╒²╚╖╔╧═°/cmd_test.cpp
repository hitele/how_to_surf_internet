#include <bits/stdc++.h>
using namespace std;
int main()
{
	system("start cmd.exe");
	return 0;
}
