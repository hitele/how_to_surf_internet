#include <bits/stdc++.h>
#include <windows.h>
#define otpt(q) printf(q);
#define otptln(q) printf(q);printf("\n");
#define lnotpt(q) printf("\n");printf(q);
#define lnotptln(q) printf("\n");printf(q);printf("\n");
#define otptin SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),14);printf(">");SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
#define err_cannot_play printf("\n你还没有解锁此关卡。\n");
#define wait_next do{otptin cin>>x;}while(x!='n' and x!='k'); if(x=='k'){otpt_know();}
using namespace std;
int Main[1+1][4+1], Side[4+1][0+1], Know[12+1];
int now_save=1;
bool auto_save=0, know_image=0;
struct STRsingle
{
	string tex="";
};
struct STRdouble
{
	string tit="";
	string tex="";
};
STRsingle Mainstr[1+1];
STRsingle Sidestr[4+1];
STRsingle MainMissionstr[4+1];
//STRsingle SideMissionstr[0+1];
STRdouble Knowstr[12+1];

void side00();
void side10();
void side20();
void side30();
void side40();
void main11();
void main12();
void main13();
void main14();

void read_save()
{
	char _x;
	int _a,_b,_c;
	//scanf("%[^\n]");scanf("%[^\n]");
	do
	{
		cin>>_x;
		if(_x=='m' or _x=='s')
		{
			cin>>_a>>_b>>_c;
			if(x=='m')
				Main[_a][_b]=_c;
			if(x=='s')
				Side[_a][_b]=_c;
		}
		else if(_x=='k')
		{
			cin>>_a;
			Know[_a]=1;
		}
	}while(_x!='e');
	return;
}
void write_save()
{
	int i,j;
	for(i=0;i<1+1;i++)
	{
		for(j=0;j<4+1;j++)
		{
			cout<<"m "<<i<<' '<<j<<' '<<Main[i][j]<<endl;
		}
	}
	for(i=0;i<4+1;i++)
	{
		for(j=0;j<0+1;j++)
		{
			cout<<"s "<<i<<' '<<j<<' '<<Main[i][j]<<endl;
		}
	}
	for(i=0;i<12+1;i++)
	{
		cout<<"k "Know[i]<<' ';
	}
	cout<<'e';
	cout<<"\n//next ln will not be read.\n//Formart:\n//0=cannot play; 1=can play; 2=completed.\n//Main X Mission X 0/1/2;\n//Side X Mission X 0/1/2;\n//Knowledge X.\n//end as 'e'.";
	return;
}
void chose_rwsave()
{
	char _x;
	lnotptln("输入：c切换档位 r读档 w存档 d重置存档 q退出 注：切换档位后不会自动读档；存档会自动存在当前档位")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='c' and _x!='r' and _x!='w' and _x!='d' and _x!='q');
	if(_x=='q')return;
	if(_x=='c')
	{
		otptln("请选择档位 1/2/3/4/5 输入档位编号")
		do
		{
			otptin
			cin>>now_save;
		}while(now_save<1 or now_save>5);
	}
	if(_x=='r')
	{
		if(now_save==1)freopen("01sav.msi","r",stdin);
		if(now_save==2)freopen("02sav.msi","r",stdin);
		if(now_save==3)freopen("03sav.msi","r",stdin);
		if(now_save==4)freopen("04sav.msi","r",stdin);
		if(now_save==5)freopen("05sav.msi","r",stdin);
		read_save();
		freopen("CON","r",stdin);
	}
	if(_x=='w')
	{
		//delete
		if(now_save==1)freopen("01sav.msi","w",stdout);
		if(now_save==2)freopen("02sav.msi","w",stdout);
		if(now_save==3)freopen("03sav.msi","w",stdout);
		if(now_save==4)freopen("04sav.msi","w",stdout);
		if(now_save==5)freopen("05sav.msi","w",stdout);
		write_save();
		freopen("CON","w",stdout);
	}
	if(_x=='d')
	{
		otptln("请选择档位 1/2/3/4/5 输入档位编号")
		int x;
		do
		{
			otptin
			cin>>x;
		}while(x<1 or x>5);
		//delete and copy
	}
	return;
}
void optin()
{
	char _x;
	cout<<"\n自动存档（任务完成时自动存到当前存档）："<<auto_save?"On":"Off"<<endl;
	cout<<"知识展示形式："<<know_image?"图片":"文字"<<endl;
	lnotptln("输入：s开关自动存档 k切换知识展示形式 q退出")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='s' and _x!='k' and _x!='q');
	if(_x=='s')
	{
		auto_save=!auto_save;
		optin();
	}
	if(_x=='k')
	{
		know_image=!know_image;
	}
	if(_x=='q')
	{
		return;
	}
}
void otpt_know()
{
	int i,x;
	bool _temp=1;
	for(i=0;i<12+1;i++)if(Know[i]==1)_temp=0;
	if(_temp)
	{
		lnotptln("当前无可查看知识！按回车继续。")
		getchar();
		return;
	}
	lnotptln("当前可查看的知识：")
	for(i=0;i<12+1;i++)
	{
		if(Know[i]==1)
		{
			cout<<"知识"<<i<<' '<<Knowstr[i].tit<<endl;
		}
	}
	lnotptln("输入你想查看的知识：")
	do
	{
		otptin
		cin>>x;
	}while(x<0 or x>12+1);
	otptln("")
	cout<<"知识"<<i<<' '<<Knowstr[x].tit<<endl;
	cout<<Knowstr[x].tex<<endl;
	lnotptln("按回车继续。")
	getchar();
	return;
}
void otpt_new_know(int x)
{
	cout<<"\n恭喜解锁新知识！知识"<<i<<' '<<Knowstr[x].tit<<endl;
	cout<<Knowstr[x].tex<<endl;
	lnotptln("按回车继续。")
	getchar();
	return;
}
void chose_mission()
{
	int x;
	string temp_a[3];
	temp_a[0]="未解锁";
	temp_a[1]="已解锁";
	temp_a[2]="已完成";
	cout<<"\n当前档位："<<now_save;
	lnotptln("输入-1换挡读档存档")
	lnotptln("请选择你的任务：")
	cout<<"编号0 支线0：		"<<Sidestr[0].tex<<"				"<<temp_a[Side[0][0]]<<endl;
	cout<<"编号1 支线1：		"<<Sidestr[1].tex<<"				"<<temp_a[Side[1][0]]<<endl;
	cout<<"编号2 支线2：		"<<Sidestr[2].tex<<"				"<<temp_a[Side[2][0]]<<endl;
	cout<<"编号3 支线3：		"<<Sidestr[3].tex<<"				"<<temp_a[Side[3][0]]<<endl;
	cout<<"编号4 主线1任务1：	"<<MainMissionstr[1].tex<<"				"<<temp_a[Main[1][1]]<<endl;
	cout<<"编号5 支线4：		"<<Sidestr[4].tex<<"				"<<temp_a[Side[4][0]]<<endl;
	cout<<"编号6 主线1任务2：	"<<MainMissionstr[2].tex<<"	"<<temp_a[Main[1][2]]<<endl;
	cout<<"编号7 主线1任务3：	"<<MainMissionstr[3].tex<<"		"<<temp_a[Main[1][3]]<<endl;
	cout<<"编号8 主线1任务4：	"<<MainMissionstr[4].tex<<"				"<<temp_a[Main[1][4]]<<endl;
	do
	{
		otptin
		cin>>x;
	}while(x<-1 or x>12+1);
	if(x==-1)
	{
		chose_rwsave();
	}
	if(x==0)
	{
		side00();
	}
	if(x==1)
	{
		side10();
	}
	if(x==2)
	{
		side20();
	}
	if(x==3)
	{
		side30();
	}
	if(x==4)
	{
		main11();
	}
	if(x==5)
	{
		side40();
	}
	if(x==6)
	{
		main12();
	}
	if(x==7)
	{
		main13();
	}
	if(x==8)
	{
		main14();
	}
	return;
}
void chose()
{
	char _x;chose_a:
	lnotptln("输入s开始line(线)任务，输入k查看知识，输入o打开设置，输入c换挡读档写档")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='s' and _x!='k' and _x!='o' and _x!='c');
	if(_x=='s')
	{
		chose_mission();
	}
	if(_x=='k')
	{
		otpt_know();
		goto chose_a;
	}
	if(_x=='o')
	{
		optin();
	}
	if(_x=='c')
	{
		chose_rwsave();
	}
	return;
}
int main()
{
	system("title 如何正确上网 beta v1.0.0 2024-8-3-0003");
	Mainstr[1].tex="使用浏览器";
	
	Sidestr[0].tex="快捷键使用教程";
	Sidestr[1].tex="下载浏览器";
	Sidestr[2].tex="安装浏览器";
	Sidestr[3].tex="卸载浏览器";
	Sidestr[4].tex="网站无法访问";
	
	MainMissionstr[1].tex="打开一个网址";
	MainMissionstr[2].tex="尝试下载一个正版软件，或找到官方网站";
	MainMissionstr[3].tex="找到7-Zip的官网并复制网址";
	MainMissionstr[4].tex="浏览器的设置";
	
	Knowstr[1].tit="快捷键";
	Knowstr[2].tit="浏览器";
	Knowstr[3].tit="桌面";
	Knowstr[4].tit="快捷方式";
	Knowstr[5].tit="开始菜单";
	Knowstr[6].tit="文件类型";
	Knowstr[7].tit="下载";
	Knowstr[8].tit="安装包";
	Knowstr[9].tit="垃圾软件";
	Knowstr[10].tit="网址、域名、IP";
	Knowstr[11].tit="网址栏、搜索框";
	Knowstr[12].tit="搜索引擎、关键字";
	
	Knowstr[1].tex="暂未更新";
	Knowstr[2].tex="暂未更新";
	Knowstr[3].tex="暂未更新";
	Knowstr[4].tex="暂未更新";
	Knowstr[5].tex="暂未更新";
	Knowstr[6].tex="暂未更新";
	Knowstr[7].tex="暂未更新";
	Knowstr[8].tex="暂未更新";
	Knowstr[9].tex="暂未更新";
	Knowstr[10].tex="暂未更新";
	Knowstr[11].tex="暂未更新";
	Knowstr[12].tex="暂未更新";
	char _x;
	otptln("嗨，朋友，感谢游玩《如何正确上网》。")
	otptln("本游戏输入完后需要按回车；如果输入错误可以重新输入。")
	otptln("如果嫌字小，在这个窗口按住Ctrl键，同时上下滚动鼠标滚轮即可调整字体。")
	otptln("输入s开始游戏，输入i查看版本信息。")
	do
	{
		otptin
		cin>>_x;
	}while(_x!='s' and _x!='i');
	if(_x=='i')
	{
		otptln("version 1.0.0 2024-8-3-0003")
		otptln("by Alone, IQ Online Studio 智商在线工作室 QQ:34067513 官网: https://hitele.github.io/how_to_surf_internet/a.html")
		otptln("按回车开始游戏")
		otptin
		getchar();getchar();
		_x='s';
	}
	if(_x=='s')
	{
		otptln("读取存档：请选择档位 1/2/3/4/5 输入档位编号")
		do
		{
			otptin
			cin>>now_save;
		}while(now_save<1 or now_save>5);
		if(now_save==1)freopen("01sav.msi","r",stdin);
		if(now_save==2)freopen("02sav.msi","r",stdin);
		if(now_save==3)freopen("03sav.msi","r",stdin);
		if(now_save==4)freopen("04sav.msi","r",stdin);
		if(now_save==5)freopen("05sav.msi","r",stdin);
		read_save();
		freopen("CON","r",stdin);
		otptln("")otptln("")
		chose();
	}
	return 0;
}
//void side00();
//void side10();
//void side20();
//void side30();
//void side40();
void main11()
{
	if(Main[1][1]==0)
	{
		err_cannot_play
		return;
	}
	int x;
	cout<<"\n主线1任务1 "<<MainMissionstr[1].tex<<endl;
	lnotptln("你已经学会了如何打开浏览器。我们为你惊心制作了一款浏览器，马上为你打开！注：自制浏览器m11版本没有上网功能，仅供游戏流程。输入n继续，输入k查看知识。")
	wait_next
	Know[10]=1;
	otpt_new_know(10);
	lnotptln("请尝试将下面这段网址复制到自制浏览器的网址栏，并打开这个网址。")
	lnotptln("")
	lnotptln("如果你正确操作的话，你将会看到一串通关码。将它输入到下面并按回车即可完成任务（太简单了）！警告：通关码为纯数字，如果你输入数字位数超过上限，或输入别的字符，程序将会卡退，耗子尾汁。");
	otptin
	cin>>x;
	while(x!=715829)
	{
		lnotpt("哦，通关码错误。请检查输入是否有误，然后重新输入。如果无法完成任务请输入123456来退出任务。")
		otptin
		cin>>x;
		if(x==123456)return;
	}
	Main[1][1]=2;
	Side[4][0]=1;
	Main[1][2]=1;
	cout<<"\n祝贺！你已完成主线1任务1 "<<MainMissionstr[1].tex<<endl;
	if(auto_save)
	{
		
		lnotpt("已为你自动保存存档至存档")
		cout<<now_save<<endl;
	}
	return;
}
//void main12();
//void main13();
//void main14();