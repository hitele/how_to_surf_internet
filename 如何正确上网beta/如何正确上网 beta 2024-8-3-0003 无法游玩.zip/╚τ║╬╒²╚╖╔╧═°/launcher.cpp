#include <bits/stdc++.h>
#include <windows.h>
#define otpt(q) printf(q);
#define otptln(q) printf(q);printf("\n");
#define lnotpt(q) printf("\n");printf(q);
#define lnotptln(q) printf("\n");printf(q);printf("\n");
#define otptin SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),14);printf(">");SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
using namespace std;
int main()
{
	char x;
	otptln("嗨，朋友，感谢游玩《如何正确上网》。")
	otptln("输入完后需要按回车。")
	otptln("这是一个启动器，用于游戏的启动与管理。")
	otptln("输入s启动游戏，输入w打开官网，输入u卸载游戏。")
	do
	{
		otptin
		cin>>x;
	}while(x!='s' and x!='w' and x!='u');
	if(x=='s')
	{
		system("start game.exe");
	}
	if(x=='w')
	{
		system("start https://hitele.github.io/how_to_surf_internet/a.html");
	}
	if(x=='u')
	{
		//
		otptln("卸载程序已经添加到你的桌面上，关闭这个窗口并打开桌面上的卸载程序即可完成卸载。")
	}
	return 0;
}
